import React from "react"

import Header from "../../Components/Header/Header"

import "./Home.scss"

export default function Home() {
  return (
    <>
      <Header />


      <h1>Home Page</h1>
    </>
  )
}


