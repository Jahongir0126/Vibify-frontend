
export default function Profile() {
  return (
    <div>
      <h1>Профиль</h1>
      {user ? (
        <p>Имя пользователя: {user.username}</p>
      ) : (
        <p>Вы не авторизованы</p>
      )}
    </div>
  );
}